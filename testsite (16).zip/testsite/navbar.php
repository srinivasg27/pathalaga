<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://maxcdn.icons8.com/fonts/line-awesome/css/line-awesome-font-awesome.min.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.css" />
<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.8/css/materialize.min.css" />
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.8/js/materialize.min.js"></script>

<body style="background-color:#f4f4f4;">
<div class="navbar-fixed" style="width:100%;overflow:scroll;">
<nav class="navbar navbar-default navbar-fixed-top" style="background-color:#fff;color:#32659E;">
    <div class="nav-wrapper" style="font-family:century Gothic;color:#32659E;">
      <a href="#!" style="float:left;color:#32659E;font-size:20px;" class="brand-logo">Pathalaga</a>
	  <a href="#" data-activates="mobile-demo" style="color:#32659E;" class="button-collapse waves-effect"><i class="material-icons">menu</i></a>
	  <a href="#" style="color:#32659E;" onclick="document.getElementById('id01').style.display='block'" class="button-collapse waves-effect"><i class="icon-location-pin" ></i></a>
	  <a href="#" class="button-collapse" style="float:right;margin-left:10px;margin-right:10px;color:#32659E;" ><i class="material-icons">perm_identity</i></a>
	  <a href="#" data-activates="mobile-demo" style="float:right;margin-right:5px;color:#32659E;" class="button-collapse waves-effect"><i class="material-icons">search</i></a>
      <ul class="center hide-on-med-and-down" style="margin-left:20%;">
        <li style="width:70%;">
	<nav class="navbar navbar-default navbar-fixed-top">
    <div class="nav-wrapper">
      <form>
        <div class="input-field" style="background-color:#fff;">
          <input id="search" type="search" class="autocomplete waves-effect" required 
		  placeholder="Search" title="Search for services, commodities, people,.."
		  onfocusin="this.style='background-color:white;'"
		  onfocusout="this.style='background-color:transparent;'" />
		  
          <label for="search"><i class="material-icons">search</i></label>
          <i class="material-icons">close</i>
        </div>
      </form>
    </div>
	</nav> 	
		
		</li>
		</ul>
		
		<ul class="right hide-on-med-and-down" >
		<style>
			.hide-on-med-and-down li a:hover{
				color:#32659E;
				background-color:white;
			}
			
		</style>
        <li style="height:auto;" title="Add a listing"><a href="#" style="color:#32659E;" class="waves-effect"><i class="material-icons" >playlist_add</i></a></li>
        <li  title="Customer Care"><a href="#" style="color:#32659E;" class="waves-effect"><i class="material-icons">ring_volume</i></a></li>
		<li title="Alert Notifications"><a href="#" style="color:#32659E;" class="waves-effect"><i class="material-icons">add_alert</i></a></li>
        <li title="Account"><a href="#" style="color:#32659E;" class="waves-effect"><i class="material-icons">perm_identity</i></a></li>
      </ul>
	
    </div>
</nav>
</div>
<div>
  <ul class="side-nav" id="mobile-demo" style="font-family:lato;">
  <div id="sidetop" style="font-family:century Gothic;margin:5% 0% 5% 0%;text-align:center;">
	CSP145
  </div>
  <div class="input-field" style="background-color:#32659E;margin-top:5%;margin-left:0%;">
          <input id="search" type="search" class="autocomplete" required 
		  placeholder="Search" title="Search for services, commodities, people,.."
		  onfocusin="this.style='background-color:white;'"
		  onfocusout="this.style='background-color:transparent;'" style="margin-left:0px;padding-left:5%;width:100%;"/>
		  
          <i class="material-icons">close</i>
        </div>
		
		
        <li style="border-bottom:solid lightgrey 1px;"><a href="#">Sass<span style="float:right;">+</span></a></li>
        <li style="border-bottom:solid lightgrey 1px;"><a href="#">Components<span style="float:right;">+</span></a></li>
		
		
		<li style="border-bottom:solid lightgrey 1px;" class="no-padding">
        <ul class="collapsible collapsible-accordion">
          <li>
            <a class="collapsible-header waves-effect">Dropdown<span style="float:right;">+</span><!--<i class="material-icons">arrow_drop_down</i>--></a>
            <div class="collapsible-body">
              <ul>
                <li><a href="#!">First</a></li>
                <li><a href="#!">Second</a></li>
                <li><a href="#!">Third</a></li>
                <li><a href="#!">Fourth</a></li>
              </ul>
            </div>
          </li>
        </ul>
      </li>
		
		
		
		
        <li style="border-bottom:solid lightgrey 1px;"><a href="#">Javascript<span style="float:right;">+</span></a></li>
        <li style="border-bottom:solid lightgrey 1px;"><a href="#">Mobile<span style="float:right;">+</span></a></li>
		
		
		
		
		
		
      </ul>
	  
	  <style>
	  /* Desktops and laptops ----------- */
	@media only screen  and (min-width : 1224px) {
		#centercontent1 {
			width:100%;background-color:#32659E;
			height:10%;margin-top:0%;color:#fff;
			font-family:century Gothic light;
		}
		#centercontent1 ul {
			margin:0% 20% 2% 15%;
		}
		#centercontent1 ul .row {
			margin-left:10%;
		}
		#centercontent1 ul .row li i {
			font-size:40px;margin:25% 2% 3% 2%;
		}
	/* Styles */
	}
	/* Smartphones (portrait and landscape) ----------- */
	@media only screen and (min-device-width : 320px) and (max-device-width : 480px) {
		
		
		.brand-logo{
			font-size:10px;
		}
		#centercontent1 {
			background-image:url('images/blue.png'); background-size: 9px 3px;background-repeat: repeat;
			!background-color:#32659E;
			background-color:#979795;
			!background-color:#000;
			!background-image:linear-gradient(135deg, #161b1d 0%, #161b1d 13%, #005a7a 50%, #005a7a 50%, #161b1d 90%);
			opacity:1;
			height:20%;margin-top:0%;color:#fff;
			font-family:century Gothic light;
			
		}
		#centercontent1 ul {
			margin:0% 0% 0% 5%;
			
		}
		#centercontent1 h6{
			padding-top:2%;
			!color:lightgrey;
			color:white;
		}
		#centercontent1 ul li {
			display: inline-block;
			vertical-align: middle;
		}
		#centercontent1 ul .row {
			margin-left:0%;
			margin-bottom:0%;
			padding-top:0%;
		}
		#centercontent1 ul .row .s3{
			margin-top:4%;
			margin-left:0%;
		}
		#centercontent1 ul .row li i {
			font-size:15px;	margin:20% 2% 0% 2%;
			border:solid white 1px;
			border-radius:50%;
			color:#fff;
			!background-color:#ecf2f8;
			padding:12px;
		}
		#centercontent1 ul .row li i:active{
			background-color:grey;
		}
		#banner1 {
			background-color:#fff;
			width:100%;
			margin:2% 1% 2% 1%;
		}
		#banner1 img {
			display:block;
			float:left;
			width:50%;
			margin-left:5%;
		}
		#banner1 h6 {
			margin-top:40%;
		}
	/* Styles */
	}
	  </style>
	  <div id="centercontent1" class="z-depth-2">
		<h6 style="color:#fff;text-align:center;margin-bottom:0px;font-family:lato;">
		START SAYING  "FEELING NEEDY"
		
		</h6>
		<ul>
		
		
		
		
		
		
		
		
		
		<div id="id01" class="w3-modal" style='height:100%;'>
    <div class="w3-modal-content w3-animate-top w3-card-8" style='height:100%;'>
      <header class="w3-container w3-black" > 
        <span onclick="document.getElementById('id01').style.display='none'" 
        class="w3-closebtn">&times;</span>
        
      </header>
       <div class="input-field" style="background-color:#000;margin-top:0%;margin-left:0%;">
          <input id="search" type="search" class="autocomplete" required 
		  placeholder="Search" title="Search for services, commodities, people,.."
		  onfocusin="this.style='background-color:white;', document.getElementById('cities_list').style='display:none;'"
		  onfocusout="this.style='background-color:transparent;', document.getElementById('cities_list').style='display:inline;'" style="margin-left:0px;padding-left:5%;width:100%;"/>
		  
          <i class="material-icons">close</i>
        </div>
		<div id="cities_list" style="color:black;margin:5%;">
			We are already here<br>
			<table>
				<tr>
					<td>Visakhapatnam</td>
				</tr>
				<tr>
					<td>Hyderabad</td>
				</tr>
				<tr>
					<td>Bangalore</td>
				</tr>
				<tr>
					<td>Pune</td>
				</tr>
			</table>
		</div>
    </div>
	</div>
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		<div class="row">
		<div class="col s3">
			<li title="Lend" style="float:left;">
			<i class="icon-people waves-effect z-depth-1"></i>
			<br>
			<h6 style="margin-top:30%;font-size:12px;text-align:center;">Hire</h6>
			</li>
		</div>
		<div class="col s3">
			<li title="Lend" style="float:left;font-family:century Gothic light">
			<i class="icon-share waves-effect z-depth-1"></i>
			<h6 style="margin-top:30%;font-size:12px;text-align:center;">Share</h6>
			</li>
		</div>
		<div class="col s3">
			<li title="Lend" style="float:left;">
			<i class="icon-present waves-effect z-depth-1"></i>
			<h6 style="margin-top:30%;font-size:12px;text-align:center;">Deliver</h6>
			</li>
		</div>
		<div class="col s3">
			<li title="Sell & Buy" style="float:left;">
			<i class="icon-basket-loaded waves-effect z-depth-1"></i>
			<h6 style="margin-top:30%;font-size:12px;text-align:center;">Trade</h6>
			</li>
		</div>
		
		</ul>
		</div>
	  </div>
	  
	  <div id="centercontent2" >
	  
	  <style>
		#centercontent2 {
			margin-top:2%;
			margin-bottom:25%;
		}
		#centercontent2 .s1 .icon-location-pin{
			float:left;
			margin:0% 0% 0% 25%;
			font-size:20px;
			color:black;
			display: table-cell;
			vertical-align: middle;
		}
		#centercontent2 .row {
			margin-top:2%;
			margin-bottom:2%;
			text-align:center;
			!margin-left:25%;
			font-family:century Gothic;
		}
		
		#centercontent2 .s1 {
			!float:left;
			text-align:center;
			margin:0% 0% 0% 25%;
			font-size:20px;
			color:black;
			display: table-cell;
			vertical-align: middle;
		}
		
		#centercontent2 .s5 a{
			color:black;
		}
		
		#nearyou{
			!width: 100%;
			height:auto;
			!margin:0 0 0 0;
			background-color:#fff;
			font-family:century Gothic;
			
			overflow: auto;
		white-space: nowrap;
		}
		
		.s4 a{
			color:black;
		}
		
		div.scrollmenu {
			!background-color: #333;
			overflow: auto;
			white-space: nowrap;
		}
		
		.scrollmenu .fa {
			font-size:30px;
			!color:#00284d;
			color:black;
		}
		.scrollmenu p {
			font-size:12px;
			!color:#00284d;
			color:#333333;
			font-family:lato;
		}

		div.scrollmenu a {
			display: inline-block;
			color:#00284d;
			text-align: center;
			padding: 14px;
			text-decoration: none;
			<!--border-right:solid 1px lightgrey;
			border-line-height: 2em;-->
			
		}
		
	  </style>
		
		<div class="row">
		<center>
		<div class="col s1">
			<i class="icon-location-pin" ></i>
		</div>
		<div class="col s5" >
			<a>Listings near you</a>
		</div>
		</center>
		</div>
		<div id="nearyou" class="z-depth-1">
			<div class="scrollmenu">
				<a href="#home" class="waves-effect">
					<i class="fa fa-motorcycle"></i>
					<p>Two-Wheelers</p>
				</a>
				<a href="#home" class="waves-effect">
					<i class="fa fa-suitcase"></i>
					<p>BackPacks</p>
				</a>
				<a href="#home" class="waves-effect">
					<i class="fa fa-money"></i>
					<p>Currency</p>
				</a>
				<a href="#home" class="waves-effect">
					<i class="fa fa-ticket"></i>
					<p>Movie Tickets</p>
				</a>
				<a href="#home" class="waves-effect">
					<i class="fa fa-taxi"></i>
					<p>Cab</p>
				</a>
				<a href="#home">
					<i class="fa fa-chevron-circle-right" style="font-size:30px;"></i>

				</a>
			</div>
		</div>
		
		
		
		
		<div class="row">
		<center>
		<div class="col s1">
			<i class="icon-fire" ></i>
		</div>
		<div class="col s5">
			<a>Trending all over</a>
		</div>
		</center>
		</div>
		<div id="nearyou" class="z-depth-1">
			<div class="scrollmenu">
				<a href="#home" class="waves-effect">
					<i class="fa fa-motorcycle"></i>
					<p>Two-Wheelers</p>
				</a>
				<a href="#home" class="waves-effect">
					<i class="fa fa-suitcase"></i>
					<p>BackPacks</p>
				</a>
				<a href="#home" class="waves-effect">
					<i class="fa fa-money"></i>
					<p>Currency</p>
				</a>
				<a href="#home" class="waves-effect">
					<i class="fa fa-ticket"></i>
					<p>Movie Tickets</p>
				</a>
				<a href="#home" class="waves-effect">
					<i class="fa fa-taxi"></i>
					<p>Cab</p>
				</a>
				<a href="#home">
					<i class="fa fa-chevron-circle-right" style="font-size:30px;"></i>

				</a>
			</div>
		</div>
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		<style>
.mySlides {display:none}
.w3-left, .w3-right, .w3-badge {cursor:pointer}
.w3-badge {height:13px;width:13px;padding:0}
</style>
<body>



<div class="w3-content w3-display-container" style="max-width:800px">
  
	
  <!img class="mySlides" src="images/BMW_R50_1958.svg" style="width:100%">
  <div id="banner1" class="mySlides" style="margin:1%;">
			<img src="images/BMW_R50_1958.svg" style="height:200px;" />
			<div class="row">
			<center>
			<div class="col s1">
				<!img src="images/BMW_R50_1958.svg" />
			</div>
			<div class="col s5">
				<h6>Y buy for 1000's.<br> Just Hire for 100's</h6>
			</div>
			</center>
			</div>
		</div>
		
  <div id="banner1" class="mySlides" style="margin:1%;">
			<img src="images/speakers.jpg" style="height:200px;" />
			<div class="row">
			<center>
			<div class="col s1">
				<!img src="images/BMW_R50_1958.svg" />
			</div>
			<div class="col s5">
				<h6>Y buy for 1000's.<br> Just Hire for 100's</h6>
			</div>
			</center>
			</div>
		</div>
		
		
		
		
		<div id="banner1" class="mySlides" style="margin:1%;">
			<img src="images/bagpack.jpg" style="height:auto;"/>
			<div class="row">
			<center>
			<div class="col s1">
				<!img src="images/BMW_R50_1958.svg" />
			</div>
			<div class="col s5">
				<h6>Y buy for 1000's.<br> Just Hire for 100's</h6>
			</div>
			</center>
			</div>
		</div>
  
  <!img class="mySlides" src="images/BMW_R50_1958.svg" style="width:100%">
  <!img class="mySlides" src="images/PW9.jpg" style="width:100%">
  <div class="w3-center w3-section w3-large w3-text-white w3-display-bottommiddle" style="width:100%">
    <div class="w3-left w3-padding-left w3-hover-text-khaki" onclick="plusDivs(-1)">&#10094;</div>
    <div class="w3-right w3-padding-right w3-hover-text-khaki" onclick="plusDivs(1)">&#10095;</div>
    <span class="w3-badge demo w3-border w3-transparent w3-hover-white" onclick="currentDiv(1)"></span>
    <span class="w3-badge demo w3-border w3-transparent w3-hover-white" onclick="currentDiv(2)"></span>
    <span class="w3-badge demo w3-border w3-transparent w3-hover-white" onclick="currentDiv(3)"></span>
  </div>
</div>

<script>
var slideIndex = 1;
showDivs(slideIndex);

function plusDivs(n) {
  showDivs(slideIndex += n);
}

function currentDiv(n) {
  showDivs(slideIndex = n);
}

function showDivs(n) {
  var i;
  var x = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("demo");
  if (n > x.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = x.length}
  for (i = 0; i < x.length; i++) {
     x[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
     dots[i].className = dots[i].className.replace(" w3-white", "");
  }
  x[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " w3-white";
}
</script>

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		<div id="onlists">
		<div class="row">
		<center>
		<div class="col s1">
			<i class="icon-layers" style="color:black;height:auto;" ></i>
		</div>
		<div class="col s5">
			<a>Awaiting you</a>
		</div>
		</center>
		</div>
			<div class="row">
				<div class="col s6" style="margin-top:2%;">
					<div id="list01" class="z-depth-3 waves-effect" style="height:auto;width:100%;background-color:#fff;opacity:1;">
					<div class="row" >
						<div class="col-s-2">
							<img src="images/sneakers.jpg" width="100%;height:100%;">
						</div>
						
					</div>
					</div>
				</div>
				<div class="col s6" style="margin-top:2%;">
					<div id="list01" class="z-depth-3 waves-effect" style="height:auto;width:100%;background-color:#fff;opacity:1;">
					<div class="row" >
						<div class="col-s-2">
							<img src="images/sneakers.jpg" width="100%;height:100%;">
						</div>
						
					</div>
					</div>
				</div>
				<div class="col s6" style="margin-top:2%;">
					<div id="list01" class="z-depth-3 waves-effect" style="height:auto;width:100%;background-color:#fff;opacity:1;">
					<div class="row" >
						<div class="col-s-2">
							<img src="images/sneakers.jpg" width="100%;height:100%;">
						</div>
						
					</div>
					</div>
				</div>
				<div class="col s6" style="margin-top:2%;">
					<div id="list01" class="z-depth-3 waves-effect" style="height:auto;width:100%;background-color:#fff;opacity:1;">
					<div class="row" >
						<div class="col-s-2">
							<img src="images/sneakers.jpg" width="100%;height:100%;">
						</div>
						
					</div>
					</div>
				</div>
				
			</div>
		</div>
		
		
		
		
		
		
		<div class="fixed-action-btn horizontal click-to-toggle">
    <a class="btn-floating btn-large z-depth-4" style="background-color:#32659E;">
      <i class="material-icons">add</i>
    </a>
    <ul>
      <li><a class="btn-floating red"><i class="material-icons">insert_chart</i></a></li>
      <li><a class="btn-floating yellow darken-1"><i class="material-icons">format_quote</i></a></li>
      <li><a class="btn-floating green"><i class="material-icons">publish</i></a></li>
      <li><a class="btn-floating blue"><i class="material-icons">attach_file</i></a></li>
    </ul>
  </div>
		
		
		
		
		
		
		
		
		
		
		
		
		</div>
	  </div>
	  
	  
	</body>  
	  

  
    <script>
  $('search.autocomplete').focus(function () {
    $(this).animate({ width: "344px" }, 500); 
});

   $(document).ready(function () {$('input.autocomplete').autocomplete({
            data: {
                "Apple": 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Apple_logo_black.svg/2000px-Apple_logo_black.svg.png',
                "Microsoft": 'https://upload.wikimedia.org/wikipedia/commons/thumb/d/da/Windows_logo_-_2002%E2%80%932012_(Multicolored).svg/2000px-Windows_logo_-_2002%E2%80%932012_(Multicolored).svg.png',
                "Google": 'https://yt3.ggpht.com/-v0soe-ievYE/AAAAAAAAAAI/AAAAAAAAAAA/OixOH_h84Po/s900-c-k-no-mo-rj-c0xffffff/photo.jpg'
            }});
			  $(".button-collapse").sideNav();
			
			});
</script>


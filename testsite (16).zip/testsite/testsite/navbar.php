<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.8/css/materialize.min.css">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.8/js/materialize.min.js"></script>
<nav class="navbar navbar-default navbar-fixed-top" style="background-color:#32659E;">
    <div class="nav-wrapper" >
      <a href="#!" class="brand-logo"><i class="material-icons">cloud</i>Pathalaga</a>
	  <a href="#" data-activates="mobile-demo" class="button-collapse"><i class="material-icons">menu</i></a>
      <ul class="center hide-on-med-and-down" style="margin-left:20%;">
        <li style="width:70%;">
	<nav class="navbar navbar-default navbar-fixed-top">
    <div class="nav-wrapper">
      <form>
        <div class="input-field" style="background-color:#32659E;">
          <input id="search" type="search" class="autocomplete" required 
		  placeholder="Search" title="Search for services, commodities, people,.."
		  onfocusin="this.style='background-color:white;'"
		  onfocusout="this.style='background-color:transparent;'" />
		  
          <label for="search"><i class="material-icons">search</i></label>
          <i class="material-icons">close</i>
        </div>
      </form>
    </div>
	</nav> 		
		
		</li>
		</ul>
		<ul class="right hide-on-med-and-down" >
		<style>
			.hide-on-med-and-down li a:hover{
				color:#32659E;
				background-color:white;
			}
			
		</style>
        <li style="border:solid white 1px;height:auto;" title="Add a listing"><a href="#" class="waves-effect"><i class="material-icons" >playlist_add</i></a></li>
        <li  title="Customer Care"><a href="#" class="waves-effect"><i class="material-icons">ring_volume</i></a></li>
		<li title="Alert Notifications"><a href="#" class="waves-effect"><i class="material-icons">add_alert</i></a></li>
        <li title="Account"><a href="#" class="waves-effect"><i class="material-icons">perm_identity</i></a></li>
      </ul>
	
    </div>
</nav>
<div>
  <ul class="side-nav" id="mobile-demo">
        <li><a href="sass.html">Sass</a></li>
        <li><a href="badges.html">Components</a></li>
        <li><a href="collapsible.html">Javascript</a></li>
        <li><a href="mobile.html">Mobile</a></li>
      </ul>
</div>
  
    <script>
  $('search.autocomplete').focus(function () {
    $(this).animate({ width: "344px" }, 500); 
});

   $(document).ready(function () {$('input.autocomplete').autocomplete({
            data: {
                "Apple": 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Apple_logo_black.svg/2000px-Apple_logo_black.svg.png',
                "Microsoft": 'https://upload.wikimedia.org/wikipedia/commons/thumb/d/da/Windows_logo_-_2002%E2%80%932012_(Multicolored).svg/2000px-Windows_logo_-_2002%E2%80%932012_(Multicolored).svg.png',
                "Google": 'https://yt3.ggpht.com/-v0soe-ievYE/AAAAAAAAAAI/AAAAAAAAAAA/OixOH_h84Po/s900-c-k-no-mo-rj-c0xffffff/photo.jpg'
            }});
			  $(".button-collapse").sideNav();
			
			});
</script>

